﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hibey.LeetCode
{
    class Program
    {
        static void Main(string[] args)
        {
            //TreeNode node = new TreeNode(1);
            //node.left = new TreeNode(2);
            //node.right = new TreeNode(3);
            ////node=  new Algorithms().InvertTree(node);
            ListNode node = new ListNode(5);
            node.next = new ListNode(1);
            node.next.next = new ListNode(9);
            //0x0000000002E82E60
            new Algorithms().IslandPerimeter(new int[4, 4] { { 0, 1, 0, 0 }, { 1, 1, 1, 0 }, { 0, 1, 0, 0 }, { 1, 1, 0, 0 } });
        }
        static void test(TreeNode t)
        {
            var r = new TreeNode(1);
            t = r;
        }
    }
}
