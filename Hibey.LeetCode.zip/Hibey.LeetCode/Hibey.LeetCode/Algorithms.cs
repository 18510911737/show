﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hibey.LeetCode
{
    /// <summary>
    /// 算法试题类
    /// </summary>
    public class Algorithms
    {
        #region 两数之和
        /*
         * 给定一个整数数组和一个目标值，找出数组中和为目标值的两个数。
         *你可以假设每个输入只对应一种答案，且同样的元素不能被重复利用。
         * 示例:
         *  给定 nums = [2, 7, 11, 15], target = 9
        *因为 nums[0] + nums[1] = 2 + 7 = 9
        *所以返回 [0, 1]
         */
        public int[] TwoSum(int[] nums, int target)
        {
            var list = new List<int>();
            for (int i = 0; i < nums.Length; i++)
            {
                if (list.Contains(target - nums[i]))
                    return new int[] { list.IndexOf(target - nums[i]), i };
                else
                    list.Add(nums[i]);
            }
            return null;
        }
        #endregion

        #region 只出现一次的数字
        /*
         * 
         * 给定一个非空整数数组，除了某个元素只出现一次以外，其余每个元素均出现两次。找出那个只出现了一次的元素。
        *说明：
        *你的算法应该具有线性时间复杂度。 你可以不使用额外空间来实现吗？
        *示例 1:
        *输入: [2,2,1]
        *输出: 1
        *示例 2:
        *输入: [4,1,2,1,2]
        *输出: 4
         *
         */
        public int SingleNumber(int[] nums)
        {
            var verify = 0;
            for (int i = 0; i < nums.Length; i++)
                verify ^= nums[i];
            return verify;
        }
        #endregion

        #region 转换成小写字母

        /*
         * 实现函数 ToLowerCase()，该函数接收一个字符串参数 str，并将该字符串中的大写字母转换成小写字母，之后返回新的字符串。
         */
        public string ToLowerCase(string str)
        {
            //实现思路:参照ASCII码  48-0 65-A 97-a
            var ascii = Encoding.ASCII.GetBytes(str.ToCharArray());
            for (int i = 0; i < ascii.Length; i++)
                if (ascii[i] > 64 && ascii[i] < 91)
                    ascii[i] += 32;
            return Encoding.ASCII.GetString(ascii);
        }

        #endregion

        #region 宝石与石头

        /* 给定字符串J 代表石头中宝石的类型，和字符串 S代表你拥有的石头。 S 中每个字符代表了一种你拥有的石头的类型，你想知道你拥有的石头中有多少是宝石。
        *J 中的字母不重复，J 和 S中的所有字符都是字母。字母区分大小写，因此"a"和"A"是不同类型的石头。
        */
        public int NumJewelsInStones(string J, string S)
        {
            var count = 0;
            var array = J.ToCharArray();
            for (int i = 0; i < array.Length; i++)
            {
                if (S.Contains(array[i]))
                    count += S.Count(f => f == array[i]);
            }
            return count;
        }

        #endregion

        #region 按奇偶校验排序数组

        /*
         * 给定一个非负整数数组 A，返回一个由 A 的所有偶数元素组成的数组，后面跟 A 的所有奇数元素。
         */
        public int[] SortArrayByParity(int[] A)
        {
            return A.OrderBy(f => f % 2 != 0).ToArray();
        }

        #endregion

        #region  翻转图像

        /*
         * 给定一个二进制矩阵 A，我们想先水平翻转图像，然后反转图像并返回结果。
         *水平翻转图片就是将图片的每一行都进行翻转，即逆序。例如，水平翻转 [1, 1, 0] 的结果是 [0, 1, 1]。
         *反转图片的意思是图片中的 0 全部被 1 替换， 1 全部被 0 替换。例如，反转 [0, 1, 1] 的结果是 [1, 0, 0]。
         */
        public int[][] FlipAndInvertImage(int[][] A)
        {
            //实现思路: 先逆序 在与1的异或校验
            for (int i = 0; i < A.Length; i++)
            {
                Array.Reverse(A[i]);
                for (int j = 0; j < A[i].Length; j++)
                    A[i][j] ^= 1;
            }
            return A;
        }

        #endregion

        #region 合并二叉树

        /**
         * Definition for a binary tree node.
         * public class TreeNode {
         *     public int val;
         *     public TreeNode left;
         *     public TreeNode right;
         *     public TreeNode(int x) { val = x; }
         * }
         */
        public TreeNode MergeTrees(TreeNode t1, TreeNode t2)
        {
            if (t1 != null && t2 != null)
                t1.val += t2.val;
            else if (t2 != null)
                t1 = new TreeNode(t2.val);
            if (t1 != null && t2 != null)
            {
                t1.left = MergeTrees(t1.left, t2.left);
                t1.right = MergeTrees(t1.right, t2.right);
            }
            return t1;
        }

        #endregion

        #region 二叉树的最大深度

        /*
         * 给定一个二叉树，找出其最大深度。
         *二叉树的深度为根节点到最远叶子节点的最长路径上的节点数。
         */

        public int MaxDepth(TreeNode root)
        {
            if (root == null)
                return 0;
            var leftDepth = MaxDepth(root.left) + 1;
            var rightDepth = MaxDepth(root.right) + 1;
            return Math.Max(leftDepth, rightDepth);
        }

        #endregion

        #region 反转字符串中的单词 III

        /*
         * 给定一个字符串，你需要反转字符串中每个单词的字符顺序，同时仍保留空格和单词的初始顺序。
         */
        public string ReverseWords(string s)
        {
            var array = s.Split(' ');
            for (int i = 0; i < array.Length; i++)
            {
                var bytes = Encoding.ASCII.GetBytes(array[i]);
                Array.Reverse(bytes);
                array[i] = Encoding.ASCII.GetString(bytes);
            }
            return string.Join(" ", array);
        }

        #endregion

        #region 反转字符串

        /*
         * 编写一个函数，其作用是将输入的字符串反转过来。
         */
        public string ReverseString(string s)
        {
            var bytes = Encoding.ASCII.GetBytes(s);
            Array.Reverse(bytes);
            return Encoding.ASCII.GetString(bytes);
        }

        #endregion

        #region 汉明距离

        /*
         * 两个整数之间的汉明距离指的是这两个数字对应二进制位不同的位置的数目。
         *给出两个整数 x 和 y，计算它们之间的汉明距离。
         */
        public int HammingDistance(int x, int y)
        {
            var count = 0;
            var strX = Convert.ToString(y, 2);
            var strY = Convert.ToString(x, 2);
            var max = Math.Max(strX.Length, strY.Length);
            var arrayX = strX.PadLeft(max, '0').ToArray();
            var arrayY = strY.PadLeft(max, '0').ToArray();
            for (int i = 0; i < max; i++)
                count += arrayX[i] ^ arrayY[i];
            return count;
        }

        #endregion

        #region 山脉数组的峰顶索引

        /*
         * 我们把符合下列属性的数组 A 称作山脉：
         *A.length >= 3
         *存在 0 < i < A.length - 1 使得A[0] < A[1] < ... A[i-1] < A[i] > A[i+1] > ... > A[A.length - 1]
         *给定一个确定为山脉的数组，返回任何满足 A[0] < A[1] < ... A[i-1] < A[i] > A[i+1] > ... > A[A.length - 1] 的 i 的值。
         */
        public int PeakIndexInMountainArray(int[] A)
        {
            return Array.IndexOf(A, A.Max());
        }

        #endregion

        #region 机器人能否返回原点

        /*
         * 在二维平面上，有一个机器人从原点 (0, 0) 开始。给出它的移动顺序，判断这个机器人在完成移动后是否在 (0, 0) 处结束。
         *移动顺序由字符串表示。字符 move[i] 表示其第 i 次移动。机器人的有效动作有 R（右），L（左），U（上）和 D（下）。如果机器人在完成所有动作后返回原点，则返回 true。否则，返回 false。
         *注意：机器人“面朝”的方向无关紧要。 “R” 将始终使机器人向右移动一次，“L” 将始终向左移动等。此外，假设每次移动机器人的移动幅度相同。
         */
        public bool JudgeCircle(string moves)
        {
            var x = 0;
            var y = 0;
            moves.ToLower().ToCharArray().ToList().ForEach(f =>
            {
                if (f == 'd')
                    y++;
                else if (f == 'u')
                    y--;
                else if (f == 'l')
                    x--;
                else if (f == 'r')
                    x++;
            });
            return x == 0 && y == 0;
        }

        #endregion

        #region 唯一摩尔斯密码词

        /*
         * 国际摩尔斯密码定义一种标准编码方式，将每个字母对应于一个由一系列点和短线组成的字符串， 比如: "a" 对应 ".-", "b" 对应 "-...", "c" 对应 "-.-.", 等等。
         */
        public int UniqueMorseRepresentations(string[] words)
        {
            var pwd = new string[] { ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.." };
            List<string> newWords = new List<string>();
            for (int i = 0; i < words.Length; i++)
            {
                var ascii = Encoding.ASCII.GetBytes(words[i].ToCharArray());
                var str = string.Empty;
                for (int j = 0; j < ascii.Length; j++)
                    str += pwd[ascii[j] - 97];
                newWords.Add(str);
            }
            return newWords.Distinct().Count();
        }

        #endregion

        #region 翻转二叉树

        public TreeNode InvertTree(TreeNode root)
        {
            if (root == null)
                return null;
            var node = root.left;
            root.left = root.right;
            root.right = node;
            root.left = InvertTree(root.left);
            root.right = InvertTree(root.right);
            return root;
        }

        #endregion

        #region 数字的补数

        /*
         * 给定一个正整数，输出它的补数。补数是对该数的二进制表示取反。
         */
        public int FindComplement(int num)
        {
            var array = Convert.ToString(num, 2).ToCharArray();
            var integer = new int[array.Length];
            for (int i = 0; i < integer.Length; i++)
                integer[i] = (Convert.ToInt32(array[i].ToString())) ^ 1;
            return Convert.ToInt32(string.Join("", integer), 2);
        }

        #endregion

        #region 键盘行

        /*
         * 给定一个单词列表，只返回可以使用在键盘同一行的字母打印出来的单词。键盘如下图所示。
         */
        public string[] FindWords(string[] words)
        {
            var r = new List<string>();
            var keyboard = new char[3][]
            {
                new[] { 'q', 'w','e','r','t','y','u','i','o','p' },
                new[] { 'a', 's','d','f','g','h','j','k','l' },
                new[] { 'z', 'x','c','v','b','n','m' }
            };
            for (int i = 0; i < words.Length; i++)
            {
                var array = words[i].ToLower().ToCharArray();
                var top = array.Intersect(keyboard[0]).Count() > 0 ? 1 : 0;
                var middle = array.Intersect(keyboard[1]).Count() > 0 ? 1 : 0;
                var down = array.Intersect(keyboard[2]).Count() > 0 ? 1 : 0;
                if (top + middle + down != 1)
                    continue;
                r.Add(words[i]);
            }
            return r.ToArray();
        }

        #endregion

        #region 自除数

        /*
         * 自除数 是指可以被它包含的每一位数除尽的数。
         *例如，128 是一个自除数，因为 128 % 1 == 0，128 % 2 == 0，128 % 8 == 0。
         *还有，自除数不允许包含 0 。
         *给定上边界和下边界数字，输出一个列表，列表的元素是边界（含边界）内所有的自除数。
         */
        public IList<int> SelfDividingNumbers(int left, int right)
        {
            var r = new List<int>();
            for (; left <= right; left++)
            {
                if (left < 10)
                    r.Add(left);
                var number = left;
                while (number > 10)
                {
                    var remainder = number % 10;
                    if (remainder == 0 || left % remainder != 0)
                        break;
                    if (number < 10)
                        r.Add(left);
                    else
                    {
                        number /= 10;
                        if (number < 10)
                        {
                            remainder = number % 10;
                            if (left % remainder == 0)
                                r.Add(left);
                        }
                    }
                }
            }
            return r;
        }

        #endregion

        #region Nim游戏

        /*
         * 你和你的朋友，两个人一起玩 Nim游戏：桌子上有一堆石头，每次你们轮流拿掉 1 - 3 块石头。 拿掉最后一块石头的人就是获胜者。你作为先手。
         *你们是聪明人，每一步都是最优解。 编写一个函数，来判断你是否可以在给定石头数量的情况下赢得游戏。
         */
        public bool CanWinNim(int n)
        {
            return n % 4 != 0;
        }

        #endregion

        #region Excel表列序号

        /*
         * 给定一个Excel表格中的列名称，返回其相应的列序号。
         */
        public int TitleToNumber(string s)
        {
            var array = s.ToCharArray();
            var index = array.Length;
            var count = 0;
            for (int i = 0; i < array.Length; i++)
                if (index-- != 1)
                    count += Convert.ToInt32(Math.Pow(26, index)) * (array[i] - 64);
                else
                    count += array[i] - 64;
            return count;
        }

        #endregion

        #region 各位相加

        /*
         * 给定一个非负整数 num，反复将各个位上的数字相加，直到结果为一位数。
         */
        public int AddDigits(int num)
        {
            return num == 0 ? 0 : (num % 9 == 0 ? 9 : num % 9);
        }

        #endregion

        #region 转置矩阵

        /*
         * 给定一个矩阵 A， 返回 A 的转置矩阵。
         *矩阵的转置是指将矩阵的主对角线翻转，交换矩阵的行索引与列索引
         */
        public int[][] Transpose(int[][] A)
        {
            var r = new int[A[0].Length][];
            for (int i = 0; i < r.Length; i++)
            {
                r[i] = new int[A.Length];
                for (int j = 0; j < A.Length; j++)
                    r[i][j] = A[j][i];
            }
            return r;
        }

        #endregion

        #region  删除链表中的节点

        /*
         * 请编写一个函数，使其可以删除某个链表中给定的（非末尾）节点，你将只被给定要求被删除的节点。
         */
        public void DeleteNode(ListNode node)
        {
            node.val = node.next.val;
            node.next = node.next.next;
        }

        #endregion

        #region 字符的最短距离

        /*
         * 给定一个字符串 S 和一个字符 C。返回一个代表字符串 S 中每个字符到字符串 S 中的字符 C 的最短距离的数组。
         */
        public int[] ShortestToChar(string S, char C)
        {
            var r = new List<int>();
            for (int i = 0; i < S.Length; i++)
            {
                var left = Math.Abs(S.IndexOf(C, i) - i);
                var right = S.LastIndexOf(C, i);
                if (right >= 0 && i - right < left)
                    r.Add(i - right);
                else
                    r.Add(left);
            }
            return r.ToArray();
        }

        #endregion

        #region  数组拆分 I

        /*
         * 给定长度为 2n 的数组, 你的任务是将这些数分成 n 对, 例如 (a1, b1), (a2, b2), ..., (an, bn) ，使得从1 到 n 的 min(ai, bi) 总和最大
         */
        public int ArrayPairSum(int[] nums)
        {
            Array.Sort(nums);
            var r = 0;
            for (int i = 0; i < nums.Length; i += 2)
                r += nums[i];
            return r;
        }

        #endregion

        #region 最小差值 I

        /*
         * 给定一个整数数组 A，对于每个整数 A[i]，我们可以选择任意 x 满足 -K <= x <= K，并将 x 加到 A[i] 中。
         *在此过程之后，我们得到一些数组 B。
         *返回 B 的最大值和 B 的最小值之间可能存在的最小差值。
         */
        public int SmallestRangeI(int[] A, int K)
        {
            var r = A.Max() - K - A.Min() - K;
            return r < 0 ? 0 : r;
        }

        #endregion

        #region 子域名访问计数

        /*
         * 一个网站域名，如"discuss.leetcode.com"，包含了多个子域名。作为顶级域名，常用的有"com"，下一级则有"leetcode.com"，最低的一级为"discuss.leetcode.com"。当我们访问域名"discuss.leetcode.com"时，也同时访问了其父域名"leetcode.com"以及顶级域名 "com"。
         *给定一个带访问次数和域名的组合，要求分别计算每个域名被访问的次数。其格式为访问次数+空格+地址，例如："9001 discuss.leetcode.com"。
         */
        public IList<string> SubdomainVisits(string[] cpdomains)
        {
            var keys = new Dictionary<string, int>();
            for (int i = 0; i < cpdomains.Length; i++)
            {
                var count = Convert.ToInt32(cpdomains[i].Split(' ')[0]);
                var domain = cpdomains[i].Split(' ')[1];
                var index = 0;
                do
                {
                    domain = domain.Substring(index);
                    if (keys.Any(f => f.Key == domain))
                        keys[domain] += Convert.ToInt32(count);
                    else
                        keys.Add(domain, Convert.ToInt32(count));
                    index = domain.IndexOf('.') + 1;
                } while (index > 0);
            }
            return keys.Select(f => $"{f.Value} {f.Key}").ToList();
        }

        #endregion

        #region 交替位二进制数

        /*
         * 给定一个正整数，检查他是否为交替位二进制数：换句话说，就是他的二进制数相邻的两个位数永不相等。
         */
        public bool HasAlternatingBits(int n)
        {
            var str = Convert.ToString(n, 2);
            return !(str.Contains("11") || str.Contains("00"));
        }

        #endregion

        #region 写字符串需要的行数

        /*
         * 我们要把给定的字符串 S 从左到右写到每一行上，每一行的最大宽度为100个单位，如果我们在写某个字母的时候会使这行超过了100 个单位，那么我们应该把这个字母写到下一行。我们给定了一个数组 widths ，这个数组 widths[0] 代表 'a' 需要的单位， widths[1] 代表 'b' 需要的单位，...， widths[25] 代表 'z' 需要的单位。
         *现在回答两个问题：至少多少行能放下S，以及最后一行使用的宽度是多少个单位？将你的答案作为长度为2的整数列表返回
         */
        public int[] NumberOfLines(int[] widths, string S)
        {
            var r = new int[2];
            var array = Encoding.ASCII.GetBytes(S);
            var count = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (count + widths[array[i] - 97] <= 100)
                {
                    count += widths[array[i] - 97];
                }
                else
                {
                    count = widths[array[i] - 97];
                    r[0] += 1;
                }
            }
            if (count != 0)
                r[0] += 1;
            r[1] = count;
            return r;
        }

        #endregion

        #region 最长特殊序列 Ⅰ

        /*
         * 给定两个字符串，你需要从这两个字符串中找出最长的特殊序列。最长特殊序列定义如下：该序列为某字符串独有的最长子序列（即不能是其他字符串的子序列）。
         *子序列可以通过删去字符串中的某些字符实现，但不能改变剩余字符的相对顺序。空序列为所有字符串的子序列，任何字符串为其自身的子序列。
         */
        public int FindLUSlength(string a, string b)
        {
            if (a == b)
                return -1;
            return Math.Max(a.Length, b.Length);
        }

        #endregion

        #region 杨辉三角

        /*
         * 给定一个非负整数 numRows，生成杨辉三角的前 numRows 行。
         */
        public IList<IList<int>> Generate(int numRows)
        {
            var r = new List<IList<int>>();
            for (int i = 0; i < numRows; i++)
            {
                var rows = new List<int> { 1 };
                for (int k = 1; k < i; k++)
                    rows.Add(r[i - 1][k] + r[i - 1][k - 1]);
                if (i > 0)
                    rows.Add(1);
                r.Add(rows);
            }
            return r;
        }

        #endregion

        #region 岛屿的周长

        /*
         * 给定一个包含 0 和 1 的二维网格地图，其中 1 表示陆地 0 表示水域。
         *网格中的格子水平和垂直方向相连（对角线方向不相连）。整个网格被水完全包围，但其中恰好有一个岛屿（或者说，一个或多个表示陆地的格子相连组成的岛屿）。
         *岛屿中没有“湖”（“湖” 指水域在岛屿内部且不和岛屿周围的水相连）。格子是边长为 1 的正方形。网格为长方形，且宽度和高度均不超过 100 。计算这个岛屿的周长。
         */
        public int IslandPerimeter(int[,] grid)
        {
            var r = 0;
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    var val = grid[i, j];
                    if (val == 1)
                    {
                        int left = 0, right = 0, up = 0, down = 0;
                        if (i - 1 >= 0)
                            up = grid[i - 1, j];
                        if (i + 1 < grid.GetLength(0))
                            down = grid[i + 1, j];
                        if (j - 1 >= 0)
                            left = grid[i, j - 1];
                        if (j + 1 < grid.GetLength(1))
                            right = grid[i, j + 1];
                        r += 4 - left - right - up - down;
                    }
                }
            }
            return r;
        }

        #endregion

        #region Fizz Buzz

        /*
         * 写一个程序，输出从 1 到 n 数字的字符串表示。
         *1. 如果 n 是3的倍数，输出“Fizz”；
         *2. 如果 n 是5的倍数，输出“Buzz”；
         *3.如果 n 同时是3和5的倍数，输出 “FizzBuzz”。
         */
        public IList<string> FizzBuzz(int n)
        {
            var r = new List<string>();
            for (int i = 1; i <= n; i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                    r.Add("FizzBuzz");
                else if (i % 3 == 0)
                    r.Add("Fizz");
                else if (i % 5 == 0)
                    r.Add("Buzz");
                else
                    r.Add(i.ToString());
            }
            return r;
        }

        #endregion

        #region 重塑矩阵

        /*
         * 在MATLAB中，有一个非常有用的函数 reshape，它可以将一个矩阵重塑为另一个大小不同的新矩阵，但保留其原始数据。
         *给出一个由二维数组表示的矩阵，以及两个正整数r和c，分别表示想要的重构的矩阵的行数和列数。
         *重构后的矩阵需要将原始矩阵的所有元素以相同的行遍历顺序填充。
         *如果具有给定参数的reshape操作是可行且合理的，则输出新的重塑矩阵；否则，输出原始矩阵。
         */
        public int[,] MatrixReshape(int[,] nums, int r, int c)
        {
            if (nums.Length != r * c)
                return nums;
            var array = new int[r, c];
            int nc = 0, nr = 0;
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int k = 0; k < array.GetLength(1); k++)
                {
                    array[i, k] = nums[nc, nr];
                    if (!(++nr < nums.GetLength(1)))
                    {
                        nr = 0;
                        nc++;
                    }
                }
            }
            return array;
        }

        #endregion

        #region 按奇偶排序数组 II

        /*
         * 给定一个非负整数数组 A， A 中一半整数是奇数，一半整数是偶数。
         *对数组进行排序，以便当 A[i] 为奇数时，i 也是奇数；当 A[i] 为偶数时， i 也是偶数。
         *你可以返回任何满足上述条件的数组作为答案。
         */
        public int[] SortArrayByParityII(int[] A)
        {
            var r = new int[A.Length];
            var oddNumber = 1;
            var evenNumber = 0;
            for (int i = 0; i < r.Length; i++)
            {
                if (A[i] % 2 == 0)
                {
                    r[evenNumber] = A[i];
                    evenNumber += 2;
                }
                else
                {
                    r[oddNumber] = A[i];
                    oddNumber += 2;
                }
            }
            return r;
        }

        #endregion

        #region N叉树的最大深度

        /*
         * 给定一个 N 叉树，找到其最大深度。
         *最大深度是指从根节点到最远叶子节点的最长路径上的节点总数。
         */
        public int MaxDepth(Node root)
        {
            if (root == null)
                return 0;
            if (root.children == null || root.children.Count == 0)
                return 1;
            var max = 0;
            for (int i = 0; i < root.children.Count; i++)
                max = Math.Max(max, MaxDepth(root.children[i]));
            return max + 1;
        }

        #endregion

        #region N叉树的后序遍历

        /*
         * 给定一个 N 叉树，返回其节点值的后序遍历。
         */
        public IList<int> Postorder(Node root)
        {
            var r = new List<int>();
            if (root == null)
                return r;
            for (int i = 0; i < root.children.Count; i++)
                r.AddRange(Postorder(root.children[i]));
            r.Add(root.val);
            return r;
        }

        #endregion

        #region  N叉树的前序遍历

        /*
         * 给定一个 N 叉树，返回其节点值的前序遍历。
         */
        public IList<int> Preorder(Node root)
        {
            var r = new List<int>();
            if (root == null)
                return r;
            r.Add(root.val);
            for (int i = 0; i < root.children.Count; i++)
                r.AddRange(Preorder(root.children[i]));
            return r;
        }

        #endregion


    }
    public class TreeNode
    {
        public int val;
        public TreeNode left;
        public TreeNode right;
        public TreeNode(int x) { val = x; }
    }

    public class ListNode
    {
        public int val;
        public ListNode next;
        public ListNode(int x) { val = x; }
    }

    public class Node
    {
        public int val;
        public IList<Node> children;

        public Node() { }
        public Node(int _val, IList<Node> _children)
        {
            val = _val;
            children = _children;
        }
    }
}
