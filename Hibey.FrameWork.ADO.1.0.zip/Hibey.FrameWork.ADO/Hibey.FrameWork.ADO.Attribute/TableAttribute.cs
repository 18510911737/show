﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.ADO.Attr
{
    public class TableAttribute:Attribute
    {
        /// <summary>
        /// 表名称
        /// </summary>
        public string TableName { get; set; }
    }
}
