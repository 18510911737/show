﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.ADO.Attr
{
    public class FieldAttribute:Attribute
    {
        /// <summary>
        /// 属性名称
        /// </summary>
        public string FieldName { get; set; }

        /// <summary>
        /// 属性类型
        /// </summary>
        public SqlDbType FieldType { get; set; }

        /// <summary>
        /// 属性大小
        /// </summary>
        public int FieldSize { get; set; }

        /// <summary>
        /// 是否自增
        /// </summary>
        public bool IsIncrement { get; set; } = false;

        /// <summary>
        /// 是否主键
        /// </summary>
        public bool IsParmaryKey { get; set; } = false;
    }
}
