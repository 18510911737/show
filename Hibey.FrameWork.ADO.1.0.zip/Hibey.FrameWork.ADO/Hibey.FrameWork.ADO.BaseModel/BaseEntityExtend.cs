﻿using Hibey.FrameWork.ADO.Attr;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.ADO.BaseModel
{
    public static class BaseEntityExtend
    {
        public static string SelectTableName<T>(this T entity)
             where T : BaseEntity, new()
        {
            var attr = typeof(T).GetCustomAttributes(typeof(TableAttribute), false);
            if (attr.Length == 0)
                return typeof(T).Name;
            return (attr[0] as TableAttribute).TableName;
        }

        public static bool Contains(this DataRow row, string contains)
        {
            if (row[contains] != DBNull.Value && row[contains] != null)
                return true;
            return false;
        }
    }
}
