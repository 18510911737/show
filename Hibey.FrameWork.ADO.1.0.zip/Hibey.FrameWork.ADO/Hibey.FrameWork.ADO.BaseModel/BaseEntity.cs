﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.ADO.BaseModel
{
    public class BaseEntity
    {
        public virtual BaseEntity ToObj(DataRow row)
        {
            var type = this.GetType();
            var r = Activator.CreateInstance(type);
            var properties = type.GetProperties();
            foreach (DataColumn column in row.Table.Columns)
            {
                var fieldName = column.ColumnName;
                var info = properties.Where(f => f.Name == fieldName).FirstOrDefault();
                if (info != null)
                {
                    if (!row.Contains(fieldName))
                        continue;
                    var dataType = column.DataType;
                    info.SetValue(r, Convert.ChangeType(row[fieldName], dataType), null);
                }
            }
            return r as BaseEntity;
        }

        public virtual IList ToList(List<DataRow> rows)
        {
            //var r =  new List<BaseEntity>(); //使用此代码无法  r as List<T>
            var r = Activator.CreateInstance(typeof(List<>).MakeGenericType(this.GetType())) as IList;
            foreach (DataRow row in rows)
                r.Add(ToObj(row));
            return r;
        }
    }
}
