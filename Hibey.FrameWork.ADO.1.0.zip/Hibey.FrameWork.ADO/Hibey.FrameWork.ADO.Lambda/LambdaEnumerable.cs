﻿using Hibey.FrameWork.ADO.BaseModel;
using Hibey.FrameWork.DBUtility.DBBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.ADO.Lambda
{
    /// <summary>
    /// Enumerable
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class LambdaEnumerable<T>
        where T : BaseEntity, new()
    {

        public DBConnection DBConn { get; set; }

        /// <summary>
        /// 操作的实体对象
        /// </summary>
        public T Entity { get; set; }

        /// <summary>
        /// 完整的sql语句
        /// </summary>
        public string Sql { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public StringBuilder Order { get; set; }

        /// <summary>
        /// 连接
        /// </summary>
        public StringBuilder Join { get; set; }

    }
}
