﻿using Hibey.FrameWork.ADO.Attr;
using Hibey.FrameWork.ADO.BaseModel;
using Hibey.FrameWork.DBUtility.DBBase;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.ADO.Lambda
{
    /// <summary>
    /// Enumerable扩展方法
    /// </summary>
    public static class LambdaEnumerableExtend
    {
        #region Enumerable

        /// <summary>
        /// 转换 Enumerable
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static LambdaEnumerable<T> AsLambdaEnumerable<T>(this T entity)
            where T : BaseEntity, new()
        {
            var r = new LambdaEnumerable<T>();
            r.Entity = entity;
            return r;
        }

        #endregion

        #region Select  [需调整]

        public static T SelectObj<T>(this LambdaEnumerable<T> enumerable, Expression<Func<T, bool>> expression = null)
             where T : BaseEntity, new()
        {
            var entity = enumerable.Entity;
            var sb = new StringBuilder($"select top 1 * from [{entity.SelectTableName()}] ");
            if (expression != null)
                sb.Append($"as {expression.Parameters[0].Name}");
            //待优化
            //var join = new StringBuilder();
            //(expression.Body as BinaryExpression).DeepMember(join);
            //sb.Append(join);
            if (expression != null)
                sb.Append($"  where {expression.Filter(entity)} ");
            sb.Append(enumerable.Order);
            enumerable.Sql = sb.ToString();
            var dt = DBCommon.SelectDataTable(sb.ToString());
            if (dt.Rows.Count > 0)
                return entity.ToObj(dt.Rows[0]) as T;
            return default(T);
        }

        public static List<T> SelectList<T>(this LambdaEnumerable<T> enumerable, Expression<Func<T, bool>> expression = null)
            where T : BaseEntity, new()
        {
            var entity = enumerable.Entity;
            var sb = new StringBuilder($"select * from [{entity.SelectTableName()}]");
            var dt = DBCommon.SelectDataTable(sb.ToString());
            if (dt.Rows.Count > 0)
                return entity.ToList(dt.Select().ToList()) as List<T>;
            return default(List<T>);
        }

        #endregion

        #region Insert

        public static int Insert<T>(this LambdaEnumerable<T> enumerable)
            where T : BaseEntity, new()
        {
            var entity = enumerable.Entity;
            var properties = typeof(T).GetProperties();
            var insert = new StringBuilder($"insert into [{entity.SelectTableName()}] (");
            var values = new StringBuilder(" values(");
            var parameters = new List<SqlParameter>();
            foreach (var info in properties)
            {
                var attr = info.GetCustomAttributes(typeof(FieldAttribute), false).FirstOrDefault() as FieldAttribute;
                if (attr == null)
                    continue;
                if (attr.IsIncrement)
                    continue;
                if (info.GetValue(entity, null) != null)
                {
                    insert.Append($"[{attr.FieldName}],");
                    values.Append($"@{ attr.FieldName},");
                    parameters.Add(new SqlParameter($"@{attr.FieldName}", info.GetValue(entity)));
                }
            }
            insert = new StringBuilder(insert.ToString().TrimEnd(',')).Append(")");
            values = new StringBuilder(values.ToString().TrimEnd(',')).Append(")");
            enumerable.Sql = $"{insert.ToString()} {values.ToString()}";
            return DBCommon.ExecuteNonQuery($"{enumerable.Sql}", parameters.ToArray());
        }

        #endregion

        #region Delete

        public static int Delete<T>(this LambdaEnumerable<T> enumerable, Expression<Func<T, bool>> expression)
            where T : BaseEntity, new()
        {
            var entity = enumerable.Entity;
            enumerable.Sql = $"delete {expression.Parameters[0].Name} from [{entity.SelectTableName()}] as {expression.Parameters[0].Name} where {expression.Filter(entity)}";
            return DBCommon.ExecuteNonQuery(enumerable.Sql);
        }

        #endregion

        #region Update

        public static int Update<T>(this LambdaEnumerable<T> enumerable, Expression<Func<T, bool>> expression = null)
            where T : BaseEntity, new()
        {
            var entity = enumerable.Entity;
            var alias = "f";
            if (expression != null)
                alias = expression.Parameters[0].Name;
            var update = new StringBuilder($"update  {alias} set ");
            var properties = typeof(T).GetProperties();
            var parameters = new List<SqlParameter>();
            foreach (var info in properties)
            {
                var attr = info.GetCustomAttributes(typeof(FieldAttribute), false).FirstOrDefault() as FieldAttribute;
                if (attr == null)
                    continue;
                if (attr.IsIncrement || attr.IsParmaryKey)
                    continue;
                update.Append($"{alias}.{attr.FieldName}=@{attr.FieldName},");
                parameters.Add(new SqlParameter($"@{attr.FieldName}", info.GetValue(entity, null)));
            }
            update = new StringBuilder(update.ToString().TrimEnd(',')).Append($" from {entity.SelectTableName()} as {alias}");
            if (expression != null)
                update.Append($" where {expression.Filter(entity)}");
            enumerable.Sql = update.ToString();
            return DBCommon.ExecuteNonQuery(enumerable.Sql, parameters.ToArray());
        }

        public static int UpdateNotFields<T>(this LambdaEnumerable<T> enumerable, Expression<Func<T, bool>> expression = null, params string[] notModifyFields)
            where T : BaseEntity, new()
        {
            var entity = enumerable.Entity;
            var alias = "f";
            if (expression != null)
                alias = expression.Parameters[0].Name;
            var update = new StringBuilder($"update  {alias} set ");
            var properties = typeof(T).GetProperties();
            var parameters = new List<SqlParameter>();
            foreach (var info in properties)
            {
                var attr = info.GetCustomAttributes(typeof(FieldAttribute), false).FirstOrDefault() as FieldAttribute;
                if (attr == null)
                    continue;
                if (attr.IsIncrement || attr.IsParmaryKey)
                    continue;
                if (notModifyFields.Any(f => f == attr.FieldName))
                    continue;
                update.Append($"{alias}.{attr.FieldName}=@{attr.FieldName},");
                parameters.Add(new SqlParameter($"@{attr.FieldName}", info.GetValue(entity, null)));
            }
            update = new StringBuilder(update.ToString().TrimEnd(',')).Append($" from {entity.SelectTableName()} as {alias}");
            if (expression != null)
                update.Append($" where {expression.Filter(entity)}");
            enumerable.Sql = update.ToString();
            return DBCommon.ExecuteNonQuery(enumerable.Sql, parameters.ToArray());
        }

        public static int UpdateFields<T>(this LambdaEnumerable<T> enumerable, Expression<Func<T, bool>> expression = null, params string[] modifyFields)
           where T : BaseEntity, new()
        {
            var entity = enumerable.Entity;
            var alias = "f";
            if (expression != null)
                alias = expression.Parameters[0].Name;
            var update = new StringBuilder($"update  {alias} set ");
            var properties = typeof(T).GetProperties();
            var parameters = new List<SqlParameter>();
            foreach (var info in properties)
            {
                var attr = info.GetCustomAttributes(typeof(FieldAttribute), false).FirstOrDefault() as FieldAttribute;
                if (attr == null)
                    continue;
                if (attr.IsIncrement || attr.IsParmaryKey)
                    continue;
                if (modifyFields.Any(f => f == attr.FieldName))
                {
                    update.Append($"{alias}.{attr.FieldName}=@{attr.FieldName},");
                    parameters.Add(new SqlParameter($"@{attr.FieldName}", info.GetValue(entity, null)));
                }
            }
            update = new StringBuilder(update.ToString().TrimEnd(',')).Append($" from {entity.SelectTableName()} as {alias}");
            if (expression != null)
                update.Append($" where {expression.Filter(entity)}");
            enumerable.Sql = update.ToString();
            return DBCommon.ExecuteNonQuery(enumerable.Sql, parameters.ToArray());
        }

        #endregion

        #region Order

        public static LambdaEnumerable<T> OrderBy<T, TResult>(this LambdaEnumerable<T> enumerable, Expression<Func<T, TResult>> func, string sort = "asc")
         where T : BaseEntity, new()
        {
            var order = new StringBuilder(" order by ");
            //expression 处理
            if (func.Body is MemberExpression)
            {
                order.Append($" {(func.Body as MemberExpression)} {sort}");
            }
            else if (func.Body is NewExpression)
            {
                foreach (var argument in (func.Body as NewExpression).Arguments)
                {
                    order.Append($" {argument as MemberExpression},");
                }
                enumerable.Order = new StringBuilder(order.ToString().TrimEnd(',')).Append($" {sort} ");
            }
            return enumerable;
        }

        public static LambdaEnumerable<T> OrderByDescending<T, TResult>(this LambdaEnumerable<T> enumerable, Expression<Func<T, TResult>> func)
            where T : BaseEntity, new() =>
            enumerable.OrderBy(func, "desc");

        #endregion

        #region  Join

        public static LambdaEnumerable<T> Join<T>(this LambdaEnumerable<T> enumerable, Expression<Func<T, bool>> expression)
            where T : BaseEntity, new()
        {
            (expression.Body as BinaryExpression).DeepMember(enumerable.Join);
            return enumerable;
        }

        #endregion
    }
}
