﻿using Hibey.FrameWork.ADO.Attr;
using Hibey.FrameWork.ADO.BaseModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.ADO.Lambda
{
    public static class ExpressionExtend
    {
        public static string Filter<T>(this LambdaExpression expression, T entity)
            where T : BaseEntity, new()
        {
            var sb = new StringBuilder();
            //Lambda表达式
            //基本操作 二元运算符表达式
            if (expression.Body is BinaryExpression)
            {
                var root = expression.Body as BinaryExpression;//根节点
                root.BinaryTree(entity, sb);
                return sb.ToString();
            }
            //复杂操作 方法调用表达式
            if (expression.Body is MethodCallExpression)
            {
                var root = expression.Body as MethodCallExpression;
                root.MethodCallAnalysis( entity, expression.Parameters[0].Name,sb);
                return sb.ToString(); ;
            }
            return "";
        }
        #region 运行表达式操作

        public static void BinaryTree<T>(this BinaryExpression binary, T entity, StringBuilder sb)
            where T : BaseEntity, new()
        {
            //左子树操作
            if (binary.Left is BinaryExpression)
                (binary.Left as BinaryExpression).BinaryTree(entity, sb);
            switch (binary.NodeType)
            {
                case ExpressionType.AndAlso:
                case ExpressionType.OrElse:
                    sb.Append($"{binary.NodeType.ConvertToString()} ");
                    break;
            }
            //右子树操作
            if (binary.Right is BinaryExpression)
                (binary.Right as BinaryExpression).BinaryTree(entity, sb);
            //无子节点-进行sql处理
            if (!(binary.Left is BinaryExpression && binary.Right is BinaryExpression))
            {
                var left = binary.Left as MemberExpression;
                if (left.Expression is MemberExpression)
                {
                    sb.Append($"{(left.Expression as MemberExpression).ToString().Replace('.', '_')}");
                    sb.Append($".{left.Member.Name}");
                }
                else
                {
                    sb.Append($"{left}");
                }

                //右节点操作
                var val = new object();
                if (binary.Right is MemberExpression)
                {
                    sb.Append($" {binary.NodeType.ConvertToString()} ");
                    var member = (binary.Right as MemberExpression);
                    if (member.Expression is ParameterExpression)
                    {
                        val = member.Member.DeclaringType.GetProperty(member.Member.Name).GetValue(entity);
                        sb.Append($" '{val}' ");
                    }
                    else
                    {
                        val = ((binary.Right as MemberExpression).Expression as ConstantExpression).Value;
                        sb.Append($" '{val.GetType().GetFields().First().GetValue(val)}' ");
                    }
                }
                else if (binary.Right is ConstantExpression)
                {
                    val = (binary.Right as ConstantExpression).Value;
                    if (val == null)
                    {
                        switch (binary.NodeType)
                        {
                            case ExpressionType.Equal:
                                sb.Append(" is null ");
                                break;
                            case ExpressionType.NotEqual:
                                sb.Append(" is not null ");
                                break;
                        }
                    }
                    else
                    {
                        sb.Append($" {binary.NodeType.ConvertToString()} ");
                        sb.Append($" '{val}' ");
                    }
                }
            }
        }

        //【未编写】
        public static void MethodCallAnalysis<T>(this MethodCallExpression method,T entity, string alias, StringBuilder sb)
            where T : BaseEntity, new()
        {
            var type = ((method.Arguments[0] as Expression) as MemberExpression).Expression.NodeType;
            switch (type)
            {
                case ExpressionType.Add:
                    break;
                case ExpressionType.AddChecked:
                    break;
                case ExpressionType.And:
                    break;
                case ExpressionType.AndAlso:
                    break;
                case ExpressionType.ArrayLength:
                    break;
                case ExpressionType.ArrayIndex:
                    break;
                case ExpressionType.Call:
                    break;
                case ExpressionType.Coalesce:
                    break;
                case ExpressionType.Conditional:
                    break;
                case ExpressionType.Constant: // List.any    sql 拼接使用 in
                    var genericTypeArguments = (method.Arguments[0] as Expression).Type.GenericTypeArguments;
                    var value = (((method.Arguments[0] as Expression) as MemberExpression).Expression as ConstantExpression).Value;
                    var list = value.GetType().GetFields()[0].GetValue(value) as IEnumerable;
                    var entitys = new List<T>();
                    foreach (var item in list)
                        entitys.Add(item as T);
                    //测试处理 未写函数 [需修改]     
                    var condition = string.Empty;
                    var inValue = new StringBuilder("(");
                    var binary = (method.Arguments[1] as LambdaExpression).Body as BinaryExpression;
                    if ((binary.Left as MemberExpression).Expression.ToString() == alias)
                    {
                        condition = binary.Left.ToString();
                        var v = (binary.Right as MemberExpression).Member.Name;
                        foreach (var item in entitys)
                        {
                            inValue.Append($"{item.GetType().GetFields()[0].GetValue(item)},");
                        }
                    }
                    else
                    {
                        condition = binary.Right.ToString();
                        var v = (binary.Left as MemberExpression).Member.Name;
                        foreach (var item in entitys)
                        {
                            inValue.Append($" '{item.GetType().GetProperty(v).GetValue(item)}',");
                        }
                    }
                    inValue = new StringBuilder($"{inValue.ToString().TrimEnd(',')} )");
                    sb.Append($" {condition} in {inValue} ");
                    break;
                case ExpressionType.Convert:
                    break;
                case ExpressionType.ConvertChecked:
                    break;
                case ExpressionType.Divide:
                    break;
                case ExpressionType.Equal:
                    break;
                case ExpressionType.ExclusiveOr:
                    break;
                case ExpressionType.GreaterThan:
                    break;
                case ExpressionType.GreaterThanOrEqual:
                    break;
                case ExpressionType.Invoke:
                    break;
                case ExpressionType.Lambda:
                    break;
                case ExpressionType.LeftShift:
                    break;
                case ExpressionType.LessThan:
                    break;
                case ExpressionType.LessThanOrEqual:
                    break;
                case ExpressionType.ListInit:
                    break;
                case ExpressionType.MemberAccess:
                    break;
                case ExpressionType.MemberInit:
                    break;
                case ExpressionType.Modulo:
                    break;
                case ExpressionType.Multiply:
                    break;
                case ExpressionType.MultiplyChecked:
                    break;
                case ExpressionType.Negate:
                    break;
                case ExpressionType.UnaryPlus:
                    break;
                case ExpressionType.NegateChecked:
                    break;
                case ExpressionType.New:
                    break;
                case ExpressionType.NewArrayInit:
                    break;
                case ExpressionType.NewArrayBounds:
                    break;
                case ExpressionType.Not:
                    break;
                case ExpressionType.NotEqual:
                    break;
                case ExpressionType.Or:
                    break;
                case ExpressionType.OrElse:
                    break;
                case ExpressionType.Parameter:
                    break;
                case ExpressionType.Power:
                    break;
                case ExpressionType.Quote:
                    break;
                case ExpressionType.RightShift:
                    break;
                case ExpressionType.Subtract:
                    break;
                case ExpressionType.SubtractChecked:
                    break;
                case ExpressionType.TypeAs:
                    break;
                case ExpressionType.TypeIs:
                    break;
                case ExpressionType.Assign:
                    break;
                case ExpressionType.Block:
                    break;
                case ExpressionType.DebugInfo:
                    break;
                case ExpressionType.Decrement:
                    break;
                case ExpressionType.Dynamic:
                    break;
                case ExpressionType.Default:
                    break;
                case ExpressionType.Extension:
                    break;
                case ExpressionType.Goto:
                    break;
                case ExpressionType.Increment:
                    break;
                case ExpressionType.Index:
                    break;
                case ExpressionType.Label:
                    break;
                case ExpressionType.RuntimeVariables:
                    break;
                case ExpressionType.Loop:
                    break;
                case ExpressionType.Switch:
                    break;
                case ExpressionType.Throw:
                    break;
                case ExpressionType.Try:
                    break;
                case ExpressionType.Unbox:
                    break;
                case ExpressionType.AddAssign:
                    break;
                case ExpressionType.AndAssign:
                    break;
                case ExpressionType.DivideAssign:
                    break;
                case ExpressionType.ExclusiveOrAssign:
                    break;
                case ExpressionType.LeftShiftAssign:
                    break;
                case ExpressionType.ModuloAssign:
                    break;
                case ExpressionType.MultiplyAssign:
                    break;
                case ExpressionType.OrAssign:
                    break;
                case ExpressionType.PowerAssign:
                    break;
                case ExpressionType.RightShiftAssign:
                    break;
                case ExpressionType.SubtractAssign:
                    break;
                case ExpressionType.AddAssignChecked:
                    break;
                case ExpressionType.MultiplyAssignChecked:
                    break;
                case ExpressionType.SubtractAssignChecked:
                    break;
                case ExpressionType.PreIncrementAssign:
                    break;
                case ExpressionType.PreDecrementAssign:
                    break;
                case ExpressionType.PostIncrementAssign:
                    break;
                case ExpressionType.PostDecrementAssign:
                    break;
                case ExpressionType.TypeEqual:
                    break;
                case ExpressionType.OnesComplement:
                    break;
                case ExpressionType.IsTrue:
                    break;
                case ExpressionType.IsFalse:
                    break;
                default:
                    break;
            }
        }

        public static void DeepMember(this BinaryExpression binary, StringBuilder sb) => binary.DeepMember(sb, null);

        private static void DeepMember(this BinaryExpression binary, StringBuilder sb, string alias = null)
        {
            if (binary.Left is BinaryExpression)
                DeepMember(binary.Left as BinaryExpression, sb);
            //右子树操作
            if (binary.Right is BinaryExpression)
                DeepMember(binary.Right as BinaryExpression, sb);
            //无子节点-进行sql处理
            if (!(binary.Left is BinaryExpression && binary.Right is BinaryExpression))
            {
                var left = binary.Left as MemberExpression;
                if (left is MemberExpression)
                {
                    var type = left.DeepMember();
                    if (type == null)
                        return;
                    //alias = (left.Expression as MemberExpression).ToString().Replace('.', '_'); //改用不使用转换方式 直接Tostirng更换别名
                    alias = left.Expression.ToString().Replace('.', '_');
                    var attrs = type.GetCustomAttributes(typeof(TableAttribute), false);
                    if (attrs.Length == 0)
                        return;
                    var t = attrs[0] as TableAttribute;
                    sb.Append($" inner join {t.TableName} as {alias}");
                    sb.Append($" on {alias}.{left.Member.Name} ");
                    sb.Append($"{binary.NodeType.ConvertToString()}");
                    var right = binary.Right as MemberExpression;  //待优化 
                    if (right?.Expression is null)
                    {
                        sb.Append($" '{binary.Right.ToString().Replace('.', '_')}' ");
                    }
                    else if (right.Expression is MemberExpression)
                    {
                        sb.Append($"{(right.Expression as MemberExpression).ToString().Replace('.', '_')}.{right.Member.Name} ");
                    }
                    else if (right.Expression is ConstantExpression)
                    {
                        var obj = (right.Expression as ConstantExpression);
                        sb.Append($" '{obj.Type.GetFields().FirstOrDefault()?.GetValue(obj.Value)}' ");
                    }
                    else
                    {
                        sb.Append(right);
                    }
                }
            }
        }

        public static Type DeepMember(this MemberExpression member)
        {
            if (member.Expression is MemberExpression)
            {
                return (member.Expression as MemberExpression).DeepMember();
            }
            else
            {
                return member.Expression.Type;
            }
        }

        #endregion

    }
}
