﻿using Hibey.FrameWork.ADO.Attr;
using Hibey.FrameWork.ADO.BaseModel;
using Hibey.FrameWork.DBUtility.DBBase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.ADO.Lambda
{
    /// <summary>
    /// Lambda sql filter
    /// </summary>
    public static class LambdaSql
    {

    }
}
