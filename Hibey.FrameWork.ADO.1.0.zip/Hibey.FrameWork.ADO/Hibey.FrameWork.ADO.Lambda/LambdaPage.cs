﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.ADO.Lambda
{
    /// <summary>
    /// 分页
    /// </summary>
    public class LambdaPage
    {
        public LambdaPage(int pageIndex, int pageSize)
        {
            this.PageIndex = pageIndex;
            this.PageSize = pageSize;
        }
        /// <summary>
        /// 页码
        /// </summary>
        public int PageIndex { get; private set; } = 1;

        /// <summary>
        /// 每页查询条件
        /// </summary>
        public int PageSize { get; private set; }

        /// <summary>
        /// 总数据条数
        /// </summary>
        public int PageTotal { get; private set; }

        /// <summary>
        /// 分页总数量
        /// </summary>
        public int PageCount
        {
            get
            {
                if (PageTotal == 0)
                    return 1;
                return PageTotal % PageSize == 0 ? PageTotal / PageSize : PageTotal / PageSize + 1;
            }
        }
    }
}
