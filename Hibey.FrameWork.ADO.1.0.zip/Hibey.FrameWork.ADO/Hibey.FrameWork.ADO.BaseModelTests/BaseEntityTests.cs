﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Hibey.FrameWork.ADO.BaseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hibey.FrameWork.DBUtility.DBBase;
using Hibey.FrameWork.ADO.Lambda;
using Hibey.FrameWork.ADO.Attr;
using System.Linq.Expressions;
using System.Transactions;
using Hibey.FrameWork.ADO.Transaction;

namespace Hibey.FrameWork.ADO.BaseModel.Tests
{
    [TestClass()]
    public class BaseEntityTests
    {
        /// <summary>
        /// 添加测试
        /// </summary>
        [TestMethod()]
        public void AddTest()
        {
            //添加方法测试
            //var r = new People();
            //r.SelectTableName();
            var user = new User();
            var test =new LambdaEnumerable<User>();
            test.Entity = user;
            test.SelectObj(f=>f.Id>=0);
            var r = user.AsLambdaEnumerable();
            r.SelectObj(f=>f.Id>=0);
           
            //for (int i = 0; i < 100; i++)
            //{
            //    r.Key = Guid.NewGuid().GetHashCode().ToString();
            //    r.Name = r.Key;
            //    r.AsLambdaEnumerable().Insert();
            //}
            //r.AsLambdaEnumerable().Insert();
            //r.AsLambdaEnumerable().Insert();
           
        }

        /// <summary>
        /// 删除测试
        /// </summary>
        [TestMethod()]
        public void DeleteTest()
        {
            var r = new People();
            r.SeqNum = 999;
            r.p = new PT() { SeqNum = 555 };
            var list = new List<People>();
            list.Add(new People() { SeqNum = 444 });
            var t= r.AsLambdaEnumerable().Delete(f=>list.Any(l=>l.SeqNum==f.SeqNum));
            var row = r.AsLambdaEnumerable().Delete(f => f.SeqNum > 90);//delete f from People as f where f.SeqNum =  '1'
            r.AsLambdaEnumerable().Delete(f => f.SeqNum == 2 && f.Name != null);//delete f from People as f where f.SeqNum =  '2' AND f.Name is not null 
            r.AsLambdaEnumerable().Delete(f => f.SeqNum == f.p.SeqNum);
        }
    }
    public static class Test
    {
     
    }

    [Table(TableName ="User")]
    public class User : BaseEntity
    {
        [Field(FieldName ="Id",IsParmaryKey =true,IsIncrement =true)]
        public int Id { get; set; }
        
        [Field(FieldName ="UserName")]
        public string UserName { get; set; }

        [Field(FieldName ="Password")]
        public string Password { get; set; }

        [Field(FieldName ="Status")]
        public byte Status { get; set; }
    }

    [Table(TableName = "People")]
    public class People : BaseEntity
    {
        [Field(IsIncrement = true, FieldName = "SeqNum")]
        public int SeqNum { get; set; }

        [Field(IsParmaryKey = true, FieldName = "Key")]
        public string Key { get; set; }

        [Field(FieldName = "Name")]
        public string Name { get; set; }

        public PT p { get; set; }
    }

    public class PT : BaseEntity
    {
        public int SeqNum { get; set; }
    }
}