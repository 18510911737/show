﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Hibey.FrameWork.ADO.Transaction
{
    /// <summary>
    /// 事务工厂类
    /// </summary>
    public static class TransactionScopeFactory
    {
        public static TransactionScope CurrentTransactionScope() => new TransactionScope();

        public static bool Commit(this TransactionScope scope)
        {
            try
            {
                scope.Complete();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                scope.Dispose();
            }
        }
        
    }
}
