﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.DBUtility.DBBase
{
    public static class DBConnectionExtend
    {
        public static void OpenExtend(this SqlConnection conn)
        {
            if (conn.State == System.Data.ConnectionState.Open)
                return;
            conn.Open();
        }

        public static void CreateInstanceExtend(this SqlCommand comm, DBConnection conn = null)
        {
            if (comm == null)
                comm = new SqlCommand(conn.ConnStr, conn.Conn);
        }
    }
}
