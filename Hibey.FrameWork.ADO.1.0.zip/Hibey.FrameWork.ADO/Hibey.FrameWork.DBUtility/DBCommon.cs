﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Hibey.FrameWork.DBUtility.DBBase
{
    public static class DBCommon
    {
        private const string connStr = "Data Source=192.144.159.47;Initial Catalog=Library;User ID=sa;Pwd =qiuqiuqiu@123;";

        public static DataTable SelectDataTable(string sql)
        {
            sql = sql.ToLower();
            if (!(sql.Contains("select") && sql.Contains("from")))
                throw new Exception("sql not exist select and from");
            var r = new DataTable();
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlCommand comm = new SqlCommand(sql, conn);
                conn.Open();
                r.Load(comm.ExecuteReader());
            }
            return r;
        }

        public static int ExecuteNonQuery(StringBuilder sql, params SqlParameter[] parameters) => (ExecuteNonQuery(sql.ToString(), parameters));
        public static int ExecuteNonQuery(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlCommand comm = new SqlCommand(sql, conn);
                conn.Open();
                for (int i = 0; i < parameters.Length; i++)
                    comm.Parameters.Add(parameters[i]);
                return comm.ExecuteNonQuery();
            }
        }

        public static bool ExecuteNonQuery(this DBConnection db, params SqlParameter[] parameters)
        {
            try
            {
                SqlCommand comm = new SqlCommand(db.ConnStr, db.Conn);
                db.Conn.OpenExtend();
                for (int i = 0; i < parameters.Length; i++)
                    comm.Parameters.Add(parameters[i]);
                comm.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        #region Tran

        public static void ExecuteNonQuery(this TransactionScope scope, string sql, SqlConnection conn, params SqlParameter[] parameters)
        {
            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            for (int i = 0; i < parameters.Length; i++)
                comm.Parameters.Add(parameters[i]);
            comm.ExecuteNonQuery();
        }

        #endregion
    }
}
