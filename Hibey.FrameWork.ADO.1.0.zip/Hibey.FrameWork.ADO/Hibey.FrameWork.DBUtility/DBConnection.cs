﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hibey.FrameWork.DBUtility.DBBase
{
    public class DBConnection
    {
        public string ConnStr { get; private set; }

        public SqlConnection Conn { get; set; }

        public SqlCommand Comm { get; set; }
    }
}
